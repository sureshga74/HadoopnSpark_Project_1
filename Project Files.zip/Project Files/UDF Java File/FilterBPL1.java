package pigudf;

import java.io.IOException;
import org.apache.pig.EvalFunc;
import org.apache.pig.data.Tuple;

 public class FilterBPL1 extends EvalFunc<Tuple>{
	public Tuple exec (Tuple input) throws IOException {
		
		if (input == null || input.size() == 0) 
			return null;
        try {
            double project_Objectives_IHHL_BPL = Double.parseDouble(input.get(2).toString());
            double project_Performance_IHHL_BPL = Double.parseDouble(input.get(10).toString());
            
            double percentage_BPL =  (project_Performance_IHHL_BPL  / project_Objectives_IHHL_BPL) * 100; 
            
            if (percentage_BPL > 80) {
            	return input;
            }
            return null;
        } catch (Exception e) {
            throw new IOException("Caught exception processing input row ", e);
        }
	}
}
